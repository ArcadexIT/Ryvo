import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../shared/providers/app_providers.dart';
import '../../../../shared/providers/di_providers.dart';
import '../../../../shared/widgets/chat_bubble.dart';
import 'package:ryvo_driver/l10n/app_localizations.dart';

class _QuickReplies extends StatelessWidget {
  const _QuickReplies({
    required this.replies,
    required this.onTap,
    required this.enabled,
  });

  final List<String> replies;
  final ValueChanged<String> onTap;
  final bool enabled;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 44,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
        itemCount: replies.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (context, index) {
          final label = replies[index];
          return Material(
            color: AppColors.surface,
            shape: const StadiumBorder(
              side: BorderSide(color: AppColors.divider),
            ),
            child: InkWell(
              customBorder: const StadiumBorder(),
              onTap: enabled ? () => onTap(label) : null,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                child: Center(
                  child: Text(
                    label,
                    style: GoogleFonts.poppins(
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                      color: enabled
                          ? AppColors.textPrimary
                          : AppColors.textSecondary,
                    ),
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

class ChatPage extends ConsumerStatefulWidget {
  final String jobId;
  const ChatPage({super.key, required this.jobId});

  @override
  ConsumerState<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends ConsumerState<ChatPage> {
  final _controller = TextEditingController();
  final _scroll = ScrollController();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      _connectChatSocket();
    });
  }

  Future<void> _connectChatSocket() async {
    try {
      await ref.read(providerSocketProvider).connect();
    } catch (_) {}
    if (!mounted) return;
    ref.read(providerSocketProvider).subscribeJob(widget.jobId);
  }

  Future<void> _sendText(String raw, {bool clearField = false}) async {
    final text = raw.trim();
    final sending =
        ref.read(chatNotifierProvider(widget.jobId)).value?.isSending ?? false;
    if (text.isEmpty || sending) return;
    if (clearField) _controller.clear();
    await ref.read(chatNotifierProvider(widget.jobId).notifier).sendMessage(text);
    _scrollToBottom();
  }

  Future<void> _send() => _sendText(_controller.text, clearField: true);

  void _sendQuickReply(String text) {
    HapticFeedback.selectionClick();
    _sendText(text);
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) {
        _scroll.animateTo(
          _scroll.position.maxScrollExtent,
          duration: const Duration(milliseconds: 250),
          curve: Curves.easeOut,
        );
      }
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    _scroll.dispose();
    super.dispose();
  }

  String _time(DateTime t) => '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}';

  List<String> _quickReplies(AppLocalizations l10n) => [
        l10n.quickReplyArrived,
        l10n.quickReplyOnMyWay,
        l10n.quickReplyWhereAreYou,
        l10n.quickReplyImOutside,
        l10n.quickReplyComeOutside,
        l10n.quickReplyOk,
      ];

  Future<void> _reportChat(String customerName, String? jobRef) async {
    final reason = await showDialog<String>(
      context: context,
      builder: (ctx) => SimpleDialog(
        backgroundColor: AppColors.surface,
        surfaceTintColor: AppColors.surface,
        title: const Text('Report this chat', style: TextStyle(color: AppColors.textPrimary, fontWeight: FontWeight.w700)),
        children: [
          for (final item in const ['Harassment or abuse', 'Safety concern', 'Spam', 'Something else'])
            SimpleDialogOption(
              onPressed: () => Navigator.pop(ctx, item),
              child: Text(item, style: const TextStyle(color: AppColors.textPrimary)),
            ),
        ],
      ),
    );
    if (reason == null || !mounted) return;
    try {
      await ref.read(supportRepositoryProvider).createTicket(
            category: 'job_issue',
            subject: 'Report trip chat',
            message: 'Reason: $reason\nCustomer: $customerName\nJob: ${jobRef ?? widget.jobId}\nJob id: ${widget.jobId}',
            jobId: widget.jobId,
          );
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Report sent. Our team will review this chat.')),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not send the report. $e'), backgroundColor: AppColors.error),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final chat = ref.watch(chatNotifierProvider(widget.jobId));
    final activeJob = ref.watch(activeJobProvider);
    final title = activeJob?.customerName ?? l10n.customer;
    final jobRef = activeJob?.jobRef;
    final messages = chat.value?.messages ?? const [];
    final isSending = chat.value?.isSending ?? false;
    final isLoading = chat.isLoading && messages.isEmpty;

    ref.listen(chatNotifierProvider(widget.jobId), (_, next) {
      if ((next.value?.messages.length ?? 0) > 0) _scrollToBottom();
    });

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.background,
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: GoogleFonts.poppins(fontSize: 16, fontWeight: FontWeight.w600)),
            Text(
              jobRef != null && jobRef.isNotEmpty ? 'Job $jobRef' : l10n.liveChat,
              style: GoogleFonts.poppins(fontSize: 11, color: AppColors.textSecondary),
            ),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'Report',
            onPressed: () => _reportChat(title, jobRef),
            icon: const Icon(Icons.flag_outlined, color: AppColors.textSecondary),
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: isLoading
                ? const Center(child: CircularProgressIndicator())
                : messages.isEmpty
                    ? Center(
                        child: Text(
                          l10n.noMessagesYetSayHiToYourCustomer,
                          textAlign: TextAlign.center,
                          style: GoogleFonts.poppins(fontSize: 13, color: AppColors.textSecondary, height: 1.5),
                        ),
                      )
                    : ListView.builder(
                        controller: _scroll,
                        padding: const EdgeInsets.all(16),
                        itemCount: messages.length,
                        itemBuilder: (_, i) {
                          final m = messages[i];
                          return ChatBubble(
                            message: m.text,
                            isSent: m.isSent,
                            timestamp: _time(m.timestamp),
                            status: m.isSent ? m.deliveryStatus : null,
                          );
                        },
                      ),
          ),
          _QuickReplies(
            replies: _quickReplies(l10n),
            enabled: !isSending,
            onTap: _sendQuickReply,
          ),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: const BoxDecoration(
              color: AppColors.surface,
              border: Border(top: BorderSide(color: AppColors.divider)),
            ),
            child: SafeArea(
              top: false,
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _controller,
                      enabled: !isSending,
                      style: GoogleFonts.poppins(color: AppColors.textPrimary),
                      decoration: InputDecoration(
                        hintText: l10n.typeAMessage,
                        hintStyle: GoogleFonts.poppins(color: AppColors.textHint),
                        filled: true,
                        fillColor: AppColors.background,
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(24), borderSide: BorderSide.none),
                        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                      ),
                      onSubmitted: (_) => _send(),
                    ),
                  ),
                  const SizedBox(width: 8),
                  GestureDetector(
                    onTap: isSending ? null : _send,
                    child: Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                        color: isSending ? AppColors.divider : AppColors.primary,
                        shape: BoxShape.circle,
                      ),
                      child: Icon(
                        isSending ? Icons.hourglass_top : Icons.send,
                        color: Colors.black,
                        size: 20,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
